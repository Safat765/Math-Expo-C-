﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionEnergy : Form
    {

        double num, num1, num2;
        public FormConvertionEnergy()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Electon volts-----------------
                if (ComboBox1 == "Electon volts" && ComboBox2 == "Jules")
                {
                    string a = "1.602177e-19";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "Kilojules")
                {
                    string a = "1.602177e-22";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "Thermal Calories")
                {
                    string a = "3.829294e-20";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "Food Calories")
                {
                    string a = "3.829294e-23";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "Foot-pounds")
                {
                    string a = "1.181705e-19";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "British Thermal Units")
                {
                    string a = "1.518570e-22";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Electon volts" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "4.450490e-26";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Jules-----------------
                else if (ComboBox1 == "Jules" && ComboBox2 == "Electon volts")
                {
                    string a = "6.241509e+18";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "Kilojules")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "Thermal Calories")
                {
                    string a = "0.239006";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "Food Calories")
                {
                    string a = "0.000239";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "Foot-pounds")
                {
                    string a = "0.737562";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "British Thermal Units")
                {
                    string a = "0.000948";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Jules" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.000000277777778";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Kilojules-----------------
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Electon volts")
                {
                    string a = "6.241509e+21";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Jules")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Thermal Calories")
                {
                    string a = "239.0057";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Food Calories")
                {
                    string a = "0.239006";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Foot-pounds")
                {
                    string a = "737.5621";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "British Thermal Units")
                {
                    string a = "0.947817";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilojules" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.000278";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Thermal Calories-----------------
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Electon volts")
                {
                    string a = "2.611448e+19";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Jules")
                {
                    string a = "4.184";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Kilojules")
                {
                    string a = "0.004184";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Food Calories")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Foot-pounds")
                {
                    string a = "3.08596";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "British Thermal Units")
                {
                    string a = "0.003966";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Thermal Calories" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Food Calories-----------------
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Electon volts")
                {
                    string a = "2.611448e+22";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Jules")
                {
                    string a = "4184";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Kilojules")
                {
                    string a = "4.184";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Thermal Calories")
                {
                    string a = "1,000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Foot-pounds")
                {
                    string a = "3,085.96";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "British Thermal Units")
                {
                    string a = "3.965666";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Food Calories" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.001162";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Foot-pounds-----------------
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Electon volts")
                {
                    string a = "8.462350e+18";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Jules")
                {
                    string a = "1.355818";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Kilojules")
                {
                    string a = "0.001356";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Thermal Calories")
                {
                    string a = "0.324048";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Food Calories")
                {
                    string a = "0.000324";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "British Thermal Units")
                {
                    string a = "0.001285";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.000000376616097";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from British Thermal Units-----------------
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Electon volts")
                {
                    string a = "6.585142e+21";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Jules")
                {
                    string a = "1,055.056";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Kilojules")
                {
                    string a = "1.055056";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Thermal Calories")
                {
                    string a = "252.1644";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Food Calories")
                {
                    string a = "252.1644";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Foot-pounds")
                {
                    string a = "778.1694";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "British Thermal Units" && ComboBox2 == "Kilowatt-hours")
                {
                    string a = "0.000293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Kilowatt-hours-----------------
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Electon volts")
                {
                    string a = "2.246943e+25";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Jules")
                {
                    string a = "3,600,000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Kilojules")
                {
                    string a = "3,600";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Thermal Calories")
                {
                    string a = "860,420.7";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Food Calories")
                {
                    string a = "860.4207";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "Foot-pounds")
                {
                    string a = "2,655,224";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilowatt-hours" && ComboBox2 == "British Thermal Units")
                {
                    string a = "3,412.141";
                    CallFromInsideAllFunction(a, labelInput);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
