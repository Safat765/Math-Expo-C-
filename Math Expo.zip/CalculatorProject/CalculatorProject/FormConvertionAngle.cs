﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionAngle : Form
    {

        double num, num1, num2;
        public FormConvertionAngle()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Degrees-----------------
                if (ComboBox1 == "Degrees" && ComboBox2 == "Radians")
                {
                    string a = "0.017453";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Degrees" && ComboBox2 == "Gradians")
                {
                    string a = "1.111111";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Radians-----------------
                else if (ComboBox1 == "Radians" && ComboBox2 == "Degrees")
                {
                    string a = "57.29578";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Radians" && ComboBox2 == "Gradians")
                {
                    string a = "63.66198";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Gradians-----------------
                else if (ComboBox1 == "Gradians" && ComboBox2 == "Degrees")
                {
                    string a = "0.9";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gradians" && ComboBox2 == "Radians")
                {
                    string a = "0.015708";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
