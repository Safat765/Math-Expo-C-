﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormCalculator : Form
    {
        double enterFirstValue, enterSecondValue;
        String op;
        string output1, output2, output3, output4, equql = " = ";
        public FormCalculator()
        {
            InitializeComponent();
        }

        private void FormCalculator_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        private void btnBackSpace_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text.Length > 0)
            {
                txtDisplay.Text = txtDisplay.Text.Remove(txtDisplay.Text.Length - 1, 1);
                txtOutput.Text = txtOutput.Text.Remove(txtOutput.Text.Length - 1, 1);
            }
            if (txtDisplay.Text == "")
            {
                txtDisplay.Text = "0";
            }
        }

        private void btnPercentAndRoot_Click(object sender, EventArgs e)
        {
            Button newBtn = (Button)sender;
            op = newBtn.Text;
            switch (op)
            {
                case "%":
                    string a = $"{txtDisplay.Text}%";
                    txtDisplay.Text = (Convert.ToDouble(txtDisplay.Text)/Convert.ToDouble(100)).ToString();
                    string b = string.Concat(a, equql);
                    txtOutput.Text = string.Concat(b, txtDisplay.Text);
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                case "√":
                    string c = $"√({txtDisplay.Text})";
                    txtDisplay.Text = (Math.Sqrt(Convert.ToDouble(txtDisplay.Text))).ToString();
                    string d = string.Concat(c, equql);
                    txtOutput.Text = string.Concat(d, txtDisplay.Text);
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                default:
                    break;
            }
        }

        private void pbHistory_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.pnlHistory.Width == 200)
                {
                    this.pnlHistory.Width = 0;
                }
                else
                    this.pnlHistory.Width = 200;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pbDelete_Click(object sender, EventArgs e)
        {
            rtbHistory.Clear();
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.txtDisplay.Text == "0")
                txtDisplay.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!txtDisplay.Text.Contains("."))
                    {
                        txtDisplay.Text = txtDisplay.Text + num.Text;
                    }
                }
                else
                {
                    txtDisplay.Text = txtDisplay.Text + num.Text;
                    txtOutput.Text = txtDisplay.Text;
                }
            }
        }

        private void FormCalculator_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.NumPad1)
                {
                    this.btn1.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void ArithmaticOperator_Click(object sender, EventArgs e)
        {
            try
            {
                Button num = (Button)sender;

                if (this.txtDisplay.Text != null)
                {
                    enterFirstValue = Convert.ToDouble(txtDisplay.Text);
                    op = num.Text;
                    output1 = string.Concat(this.txtDisplay.Text," ", op, " ");
                    txtDisplay.Clear();
                    this.txtOutput.Text = output1;
                }
                else
                    return;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            output2 = string.Concat(output1, txtDisplay.Text);
            this.txtOutput.Text = output1;

            enterSecondValue = Convert.ToDouble(txtDisplay.Text);
            output3 = string.Concat(output1, txtDisplay.Text, equql);
            this.txtOutput.Text = output3;

            switch (op)
            {
                case "+":
                    txtDisplay.Text = (this.enterFirstValue + this.enterSecondValue).ToString();

                    output4 = string.Concat(output3, txtDisplay.Text);
                    this.txtOutput.Text = output4;
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                case "-":
                    txtDisplay.Text = (this.enterFirstValue - this.enterSecondValue).ToString();

                    output4 = string.Concat(output3, txtDisplay.Text);
                    this.txtOutput.Text = output4;
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                case "×":
                    txtDisplay.Text = (this.enterFirstValue * this.enterSecondValue).ToString();

                    output4 = string.Concat(output3, txtDisplay.Text);
                    this.txtOutput.Text = output4;
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                case "÷":
                    txtDisplay.Text = (this.enterFirstValue / this.enterSecondValue).ToString();

                    output4 = string.Concat(output3, txtDisplay.Text);
                    this.txtOutput.Text = output4;
                    rtbHistory.AppendText($"{txtOutput.Text}\n");
                    break;

                default:
                    MessageBox.Show("Something is worng");
                    break;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtDisplay.Text = "0";
            this.txtOutput.Text = "Output";
        }
    }
}
