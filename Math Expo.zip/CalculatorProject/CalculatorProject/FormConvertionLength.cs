﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionLength : Form
    {
        public FormConvertionLength()
        {
            InitializeComponent();
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
