﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormVolume : Form
    {
        double num, num1, num2;
        public FormVolume()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void FormVolume_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Milliliters-----------------
                if (ComboBox1 == "Milliliters" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Liters")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "0.202884";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "0.067628";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.033814";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.004227";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.002113";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.001057";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.000264";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Cubic inches")
                {
                    string a = "0.061024";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000035";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "0.168936";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.056312";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.035195";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.00176";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.00088";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Milliliters" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.00022";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cubic centimeters-----------------
                if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Milliliters")
                {
                    string a = "1";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Liters")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "0.202884";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "0.067628";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.033814";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.004227";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.002113";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.001057";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.000264";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Cubic inches")
                {
                    string a = "0.061024";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000035";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "0.168936";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.056312";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.035195";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.00176";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.00088";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic centimeters" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.00022";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                // -----------------all convertion from Liters----------------------

                if (ComboBox1 == "Liters" && ComboBox2 == "Milliliters")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "202.8841";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "67.62805";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "33.81402";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cups (US)")
                {
                    string a = "4.226753";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Prints (US)")
                {
                    string a = "2.113376";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Quarts (US)")
                {
                    string a = "1.056688";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.264172";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cubic inches")
                {
                    string a = "61.02374";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.035315";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.001308";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "168.9364";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "56.31213";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "35.19508";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Pints (UK)")
                {
                    string a = "1.759754";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.879877";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Liters" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.219969";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cubic meters----------------------

                if (ComboBox1 == "Cubic meters" && ComboBox2 == "Milliliters")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Liters")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "202884.1";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "67628.05";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "33814.02";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Cups (US)")
                {
                    string a = "4226.753";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Prints (US)")
                {
                    string a = "2113.376";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Quarts (US)")
                {
                    string a = "1056.688";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Gallons (US)")
                {
                    string a = "264.1721";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Cubic inches")
                {
                    string a = "61023.74";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Cubic feet")
                {
                    string a = "35.31467";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Cubic yards")
                {
                    string a = "1.307951";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "168936.4";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "56312.13";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "35195.08";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Pints (UK)")
                {
                    string a = "1759.754";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "879.877";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic meters" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "219.9692";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Tespoons (US)----------------------

                if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "4.928922";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "4.928922";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.004929";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000005";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "0.333333";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.166667";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.020833";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.010417";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.005208";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.001302";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "0.300781";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000174";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000006";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.277558";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.173474";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.008674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.004337";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tespoons (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.001084";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Tablespoons (US)----------------------

                if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "14.78676";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "14.78676";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.014787";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000015";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "3";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.0625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.03125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.015625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.003906";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "0.902344";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000522";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000019";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "2.498023";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.520421";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.026021";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.013011";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.003253";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Fiuid ounces (US)----------------------

                if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "29.57353";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "29.57353";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.029574";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.00003";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "6";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.0625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.03125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.007812";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "1.804688";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.001044";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000039";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "4.996045";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "1.665348";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "1.665348";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.052042";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.026021";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fiuid ounces (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.006505";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cups (US)----------------------

                if (ComboBox1 == "Cups (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "236.5882";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "236.5882";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.236588";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000237";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "48";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "16";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "8";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.25";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.0625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "14.4375";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.008355";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000309";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "39.96836";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "13.32279";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "8.326742";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.416337";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.208169";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cups (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.052042";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Prints (US)----------------------

                if (ComboBox1 == "Prints (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "473.1765";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "473.1765";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.473176";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000473";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "96";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "32";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "16";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "28.875";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.01671";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000619";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "79.93672";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "26.64557";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "16.65348";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Prints (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.208169";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Quarts (US)----------------------

                if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "946.3529";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "946.3529";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Liters")
                {
                    string a = "0.946353";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000946";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "192";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "64";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "32";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "4";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.25";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "57.75";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.03342";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.001238";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "159.8734";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "53.29115";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "33.30697";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "1.665348";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.208169";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Gallons (US)----------------------

                if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Milliliters")
                {
                    string a = "3785.412";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "3785.412";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Liters")
                {
                    string a = "3.785412";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.003785";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "768";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "256";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "128";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cups (US)")
                {
                    string a = "16";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Prints (US)")
                {
                    string a = "8";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "4";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cubic inches")
                {
                    string a = "231";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.133681";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.004951";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "639.4938";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "213.1646";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "133.2279";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "6.661393";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "3.330697";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (US)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.832674";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cubic inches----------------------

                if (ComboBox1 == "Cubic inches" && ComboBox2 == "Milliliters")
                {
                    string a = "16.38706";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "16.38706";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Liters")
                {
                    string a = "0.016387";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000016";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "3.324675";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "1.108225";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.554113";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.069264";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.034632";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.017316";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.004329";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000579";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000021";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "2.768371";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.92279";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.576744";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.028837";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.014419";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic inches" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.003605";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cubic feet----------------------

                if (ComboBox1 == "Cubic feet" && ComboBox2 == "Milliliters")
                {
                    string a = "28316.85";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "28316.85";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Liters")
                {
                    string a = "28.31685";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.028317";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "5745.039";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "1915.013";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "957.5065";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Cups (US)")
                {
                    string a = "119.6883";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Prints (US)")
                {
                    string a = "59.84416";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Quarts (US)")
                {
                    string a = "29.92208";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Gallons (US)")
                {
                    string a = "7.480519";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Cubic inches")
                {
                    string a = "1728";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.037037";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "4783.746";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "1594.582";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "996.6137";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Pints (UK)")
                {
                    string a = "49.83068";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "24.91534";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic feet" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "6.228835";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Cubic yards----------------------

                if (ComboBox1 == "Cubic yards" && ComboBox2 == "Milliliters")
                {
                    string a = "764554.9";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "764554.9";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Liters")
                {
                    string a = "764.5549";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.764555";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "155116.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "51705.35";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "25852.68";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Cups (US)")
                {
                    string a = "3231.584";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Prints (US)")
                {
                    string a = "1615.792";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Quarts (US)")
                {
                    string a = "807.8961";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Gallons (US)")
                {
                    string a = "201.974";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Cubic inches")
                {
                    string a = "46656";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Cubic feet")
                {
                    string a = "27";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "129161.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "43053.71";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "26908.57";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Pints (UK)")
                {
                    string a = "1345.428";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "672.7142";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Cubic yards" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "168.1786";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Teaspoons (UK)----------------------

                if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "5.919388";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "5.919388";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Liters")
                {
                    string a = "0.005919";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000006";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "1.20095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "0.400317";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.200158";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.02502";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.01251";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.006255";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.001564";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "0.361223";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000209";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000008";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "0.333333";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.208333";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.010417";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.005208";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Teaspoons (UK)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.001302";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Tablespoons (UK)----------------------

                if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "17.75816";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "17.75816";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Liters")
                {
                    string a = "0.017758";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000018";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "3.60285";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "1.20095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.600475";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.075059";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.03753";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.018765";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.004691";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "1.08367";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.000627";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000023";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "3";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "0.625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.03125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.015625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Tablespoons (UK)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.003906";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Fluid ounces (UK)----------------------

                if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "28.41306";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "28.41306";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Liters")
                {
                    string a = "0.028413";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000028";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "5.76456";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "1.92152";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "0.96076";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "0.120095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "0.060047";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.030024";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.007506";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "1.733871";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.001003";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000037";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "4.8";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "1.6";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "0.05";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.025";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Fluid ounces (UK)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.00625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Pints (UK)----------------------

                if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "568.2613";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "568.2613";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Liters")
                {
                    string a = "0.568261";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.000568";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "115.2912";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "38.4304";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "19.2152";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "2.4019";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "1.20095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "0.600475";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.150119";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "34.67743";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.020068";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.000743";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "96";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "32";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "20";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "0.5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pints (UK)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.125";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Quarts (UK)----------------------

                if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "1136.523";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "1136.523";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Liters")
                {
                    string a = "1.136523";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.001137";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "230.5824";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "76.8608";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "38.4304";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "4.8038";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "2.4019";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "1.20095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "0.300237";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "69.35486";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.040136";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.001487";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "192";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "64";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "40";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Quarts (UK)" && ComboBox2 == "Gallons (UK)")
                {
                    string a = "0.25";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Gallons (UK)----------------------

                if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Milliliters")
                {
                    string a = "4546.09";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cubic centimeters")
                {
                    string a = "4546.09";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Liters")
                {
                    string a = "4.54609";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cubic meters")
                {
                    string a = "0.004546";
                    CallFromInsideAllFunction(a, labelInput);//
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Tespoons (US)")
                {
                    string a = "922.3295";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Tablespoons (US)")
                {
                    string a = "307.4432";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Fiuid ounces (US)")
                {
                    string a = "153.7216";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cups (US)")
                {
                    string a = "19.2152";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Prints (US)")
                {
                    string a = "9.607599";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Quarts (US)")
                {
                    string a = "4.8038";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Gallons (US)")
                {
                    string a = "1.20095";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cubic inches")
                {
                    string a = "277.4194";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cubic feet")
                {
                    string a = "0.160544";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Cubic yards")
                {
                    string a = "0.005946";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Teaspoons (UK)")
                {
                    string a = "768";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Tablespoons (UK)")
                {
                    string a = "256";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Fluid ounces (UK)")
                {
                    string a = "160";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Pints (UK)")
                {
                    string a = "8";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Gallons (UK)" && ComboBox2 == "Quarts (UK)")
                {
                    string a = "4";
                    CallFromInsideAllFunction(a, labelInput);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);

                this.Comparecmb();

                if (lblOutput.Text.Length < 1)
                {
                    lblOutput.Text = "0";
                }
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
