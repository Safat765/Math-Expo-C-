﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionMass : Form
    {

        double num, num1, num2;
        public FormConvertionMass()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Carats-----------------
                if (ComboBox1 == "Carats" && ComboBox2 == "Miligram")
                {
                    string a = "200";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Centigrams")
                {
                    string a = "20";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Decigrams")
                {
                    string a = "2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Grams")
                {
                    string a = "0.2";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Dekagrams")
                {
                    string a = "0.02";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Hectograms")
                {
                    string a = "0.002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Kilograms")
                {
                    string a = "0.0002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.0000002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Ounces")
                {
                    string a = "0.007055";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Pounds")
                {
                    string a = "0.000441";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Stone")
                {
                    string a = "0.000031";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000000220462262";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Carats" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000000196841306";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Miligram-----------------
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Carats")
                {
                    string a = "0.005";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Centigrams")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Decigrams")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Grams")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Dekagrams")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Hectograms")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Kilograms")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.000000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Ounces")
                {
                    string a = "0.000035";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Pounds")
                {
                    string a = "0.000002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Stone")
                {
                    string a = "0.000000157473044";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000000001102311";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miligram" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000000000984207";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Centigrams-----------------
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Carats")
                {
                    string a = "0.05";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Miligram")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Decigrams")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Grams")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Dekagrams")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Hectograms")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Kilograms")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.00000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Ounces")
                {
                    string a = "0.000353";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Pounds")
                {
                    string a = "0.000022";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Stone")
                {
                    string a = "0.000002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000000011023113";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centigrams" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000000009842065";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Decigrams-----------------
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Carats")
                {
                    string a = "0.5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Miligram")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Centigrams")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Grams")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Dekagrams")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Hectograms")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Kilograms")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.0000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Ounces")
                {
                    string a = "0.003527";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Pounds")
                {
                    string a = "0.00022";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Stone")
                {
                    string a = "0.000016";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000000110231131";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Decigrams" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000000098420653";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Grams-----------------
                else if (ComboBox1 == "Grams" && ComboBox2 == "Carats")
                {
                    string a = "5";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Miligram")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Centigrams")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Decigrams")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Dekagrams")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Hectograms")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Kilograms")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Ounces")
                {
                    string a = "0.035274";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Pounds")
                {
                    string a = "0.002205";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Stone")
                {
                    string a = "0.000157";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Grams" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000000984206528";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Dekagrams-----------------
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Carats")
                {
                    string a = "50";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Miligram")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Centigrams")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Decigrams")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Grams")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Hectograms")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Kilograms")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Ounces")
                {
                    string a = "0.35274";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Pounds")
                {
                    string a = "0.022046";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Stone")
                {
                    string a = "0.001575";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000011";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Dekagrams" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Hectograms-----------------
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Carats")
                {
                    string a = "500";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Miligram")
                {
                    string a = "100000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Centigrams")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Decigrams")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Grams")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Dekagrams")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Kilograms")
                {
                    string a = "0.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Ounces")
                {
                    string a = "3.527396";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Pounds")
                {
                    string a = "0.220462";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Stone")
                {
                    string a = "0.015747";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.00011";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectograms" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000098";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Kilograms-----------------
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Carats")
                {
                    string a = "5000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Miligram")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Centigrams")
                {
                    string a = "100000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Decigrams")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Grams")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Dekagrams")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Hectograms")
                {
                    string a = "10";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Ounces")
                {
                    string a = "35.27396";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Pounds")
                {
                    string a = "2.204623";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Stone")
                {
                    string a = "0.157473";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.001102";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilograms" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000984";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Metric tonnes-----------------
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Carats")
                {
                    string a = "5000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Miligram")
                {
                    string a = "1000000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Centigrams")
                {
                    string a = "100000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Decigrams")
                {
                    string a = "10000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Grams")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Dekagrams")
                {
                    string a = "100000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Hectograms")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Kilograms")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Ounces")
                {
                    string a = "35273.96";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Pounds")
                {
                    string a = "2204.623";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Stone")
                {
                    string a = "157.473";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Short tons (US)")
                {
                    string a = "1.102311";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Metric tonnes" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.984207";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Ounces-----------------
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Carats")
                {
                    string a = "141.7476";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Miligram")
                {
                    string a = "28349.52";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Centigrams")
                {
                    string a = "2834.952";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Decigrams")
                {
                    string a = "283.4952";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Grams")
                {
                    string a = "28.34952";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Dekagrams")
                {
                    string a = "2.834952";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Hectograms")
                {
                    string a = "0.283495";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Kilograms")
                {
                    string a = "0.02835";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.000028";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Pounds")
                {
                    string a = "0.0625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Stone")
                {
                    string a = "0.004464";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.000031";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Ounces" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000028";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Pounds-----------------
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Carats")
                {
                    string a = "2267.962";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Miligram")
                {
                    string a = "453592.4";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Centigrams")
                {
                    string a = "45359.24";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Decigrams")
                {
                    string a = "4535.924";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Grams")
                {
                    string a = "453.5924";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Dekagrams")
                {
                    string a = "45.35924";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Hectograms")
                {
                    string a = "4.535924";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Kilograms")
                {
                    string a = "0.453592";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.000454";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Ounces")
                {
                    string a = "16";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Stone")
                {
                    string a = "0.071429";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.0005";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pounds" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.000446";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Stone-----------------
                else if (ComboBox1 == "Stone" && ComboBox2 == "Carats")
                {
                    string a = "31751.47";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Miligram")
                {
                    string a = "6350293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Centigrams")
                {
                    string a = "635029.3";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Decigrams")
                {
                    string a = "63502.93";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Grams")
                {
                    string a = "6350.293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Dekagrams")
                {
                    string a = "635.0293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Hectograms")
                {
                    string a = "63.50293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Kilograms")
                {
                    string a = "6.350293";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.00635";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Ounces")
                {
                    string a = "224";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Pounds")
                {
                    string a = "14";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Short tons (US)")
                {
                    string a = "0.007";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Stone" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.00625";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Short tons (US)-----------------
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Carats")
                {
                    string a = "4535924";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Miligram")
                {
                    string a = "907184740";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Centigrams")
                {
                    string a = "90718474";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Decigrams")
                {
                    string a = "9071847";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Grams")
                {
                    string a = "907184.7";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Dekagrams")
                {
                    string a = "90718.47";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Hectograms")
                {
                    string a = "9071.847";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Kilograms")
                {
                    string a = "907.1847";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Metric tonnes")
                {
                    string a = "0.907185";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Ounces")
                {
                    string a = "32000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Pounds")
                {
                    string a = "2000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Stone")
                {
                    string a = "142.8571";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Short tons (US)" && ComboBox2 == "Long tons (UK)")
                {
                    string a = "0.892857";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Long tons (UK)-----------------
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Carats")
                {
                    string a = "5080235";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Miligram")
                {
                    string a = "1016046909";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Centigrams")
                {
                    string a = "101604691";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Decigrams")
                {
                    string a = "10160469";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Grams")
                {
                    string a = "1016047";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Dekagrams")
                {
                    string a = "101604.7";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Hectograms")
                {
                    string a = "10160.47";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Kilograms")
                {
                    string a = "1016.047";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Metric tonnes")
                {
                    string a = "1.016047";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Ounces")
                {
                    string a = "35840";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Pounds")
                {
                    string a = "2240";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Stone")
                {
                    string a = "160";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Long tons (UK)" && ComboBox2 == "Short tons (US)")
                {
                    string a = "1.12";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
