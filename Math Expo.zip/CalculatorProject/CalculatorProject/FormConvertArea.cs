﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertArea : Form
    {
        double num, num1, num2;
        public FormConvertArea()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }
        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Square millimeters-----------------
                if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square centimeters")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square meters")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Hectares")
                {
                    string a = "0.0000000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.000000000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square inches")
                {
                    string a = "0.00155";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square feet")
                {
                    string a = "0.000011";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square yards")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Acres")
                {
                    string a = "0.000000000247105";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square millimeters" && ComboBox2 == "Square miles")
                {
                    string a = "0.000000000000386";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square centimeters-----------------
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square millimeters")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square meters")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Hectares")
                {
                    string a = "0.00000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.0000000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square inches")
                {
                    string a = "0.155";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square feet")
                {
                    string a = "0.001076";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square yards")
                {
                    string a = "0.00012";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Acres")
                {
                    string a = "0.000000024710538";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square centimeters" && ComboBox2 == "Square miles")
                {
                    string a = "0.00000000003861";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square meters-----------------
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square millimeters")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square centimeters")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Hectares")
                {
                    string a = "0.0001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square inches")
                {
                    string a = "1550.003";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square feet")
                {
                    string a = "10.76391";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square yards")
                {
                    string a = "1.19599";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Acres")
                {
                    string a = "0.000247";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square meters" && ComboBox2 == "Square miles")
                {
                    string a = "0.000000386102159";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Hectares-----------------
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square millimeters")
                {
                    string a = "10000000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square centimeters")
                {
                    string a = "100000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square meters")
                {
                    string a = "10000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square inches")
                {
                    string a = "15500031";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square feet")
                {
                    string a = "107639.1";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square yards")
                {
                    string a = "11959.9";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Acres")
                {
                    string a = "2.471054";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hectares" && ComboBox2 == "Square miles")
                {
                    string a = "0.003861";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square Kilometers-----------------
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square millimeters")
                {
                    string a = "1000000000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square centimeters")
                {
                    string a = "10000000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square meters")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Hectares")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square inches")
                {
                    string a = "1550003100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square feet")
                {
                    string a = "10763910";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square yards")
                {
                    string a = "1195990";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Acres")
                {
                    string a = "247.1054";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square Kilometers" && ComboBox2 == "Square miles")
                {
                    string a = "0.386102";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square inches-----------------
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square millimeters")
                {
                    string a = "645.16";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square centimeters")
                {
                    string a = "6.4516";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square meters")
                {
                    string a = "0.000645";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Hectares")
                {
                    string a = "0.000000064516";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.00000000064516";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square feet")
                {
                    string a = "0.006944";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square yards")
                {
                    string a = "0.000772";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Acres")
                {
                    string a = "0.000000159422508";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square inches" && ComboBox2 == "Square miles")
                {
                    string a = "0.000000000249098";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square feet-----------------
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square millimeters")
                {
                    string a = "92903.04";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square centimeters")
                {
                    string a = "929.0304";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square meters")
                {
                    string a = "0.092903";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Hectares")
                {
                    string a = "0.000009";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.00000009290304";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square inches")
                {
                    string a = "144";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square yards")
                {
                    string a = "0.111111";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Acres")
                {
                    string a = "0.000023";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square feet" && ComboBox2 == "Square miles")
                {
                    string a = "0.000000035870064";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square yards-----------------
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square millimeters")
                {
                    string a = "836127.4";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square centimeters")
                {
                    string a = "8361.274";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square meters")
                {
                    string a = "0.836127";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Hectares")
                {
                    string a = "0.000084";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.00000083612736";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square inches")
                {
                    string a = "1296";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square feet")
                {
                    string a = "9";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Acres")
                {
                    string a = "0.000207";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square yards" && ComboBox2 == "Square miles")
                {
                    string a = "0.000000322830579";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Acres-----------------
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square millimeters")
                {
                    string a = "4046856422";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square centimeters")
                {
                    string a = "40468564";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square meters")
                {
                    string a = "4046.856";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Hectares")
                {
                    string a = "0.404686";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square Kilometers")
                {
                    string a = "0.004047";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square inches")
                {
                    string a = "6272640";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square feet")
                {
                    string a = "43560";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square yards")
                {
                    string a = "4840";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Acres" && ComboBox2 == "Square miles")
                {
                    string a = "0.001563";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Square miles-----------------
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square millimeters")
                {
                    string a = "2589988110336";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square centimeters")
                {
                    string a = "25899881103";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square meters")
                {
                    string a = "2589988";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Hectares")
                {
                    string a = "258.9988";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square Kilometers")
                {
                    string a = "2.589988";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square inches")
                {
                    string a = "4014489600";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square feet")
                {
                    string a = "27878400";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Square yards")
                {
                    string a = "3097600";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Square miles" && ComboBox2 == "Acres")
                {
                    string a = "640";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }
    }
}
