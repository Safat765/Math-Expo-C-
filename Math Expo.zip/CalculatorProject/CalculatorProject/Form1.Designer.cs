﻿namespace CalculatorProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlForm1CenterDisplay = new System.Windows.Forms.Panel();
            this.pnlWelcomePicture = new System.Windows.Forms.Panel();
            this.uperPanel = new System.Windows.Forms.Panel();
            this.btnSlide = new System.Windows.Forms.PictureBox();
            this.pnlMenuVartical = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlManu = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnForm1Home = new System.Windows.Forms.Button();
            this.btnForm1StandardCalculator = new System.Windows.Forms.Button();
            this.btnScientificCalculator = new System.Windows.Forms.Button();
            this.btnNotepadCalculator = new System.Windows.Forms.Button();
            this.btnConversion = new System.Windows.Forms.Button();
            this.pnlConvertionContainer = new System.Windows.Forms.Panel();
            this.btnAngle = new System.Windows.Forms.Button();
            this.btnForm1SbDiscount = new System.Windows.Forms.Button();
            this.btnForm1SbSpeed = new System.Windows.Forms.Button();
            this.btnForm1SbPressure = new System.Windows.Forms.Button();
            this.btnForm1SbEnergy = new System.Windows.Forms.Button();
            this.btnForm1SbTemp = new System.Windows.Forms.Button();
            this.btnForm1SbTime = new System.Windows.Forms.Button();
            this.btnForm1SbMass = new System.Windows.Forms.Button();
            this.btnForm1SbVolume = new System.Windows.Forms.Button();
            this.btnForm1SbArea = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pnlButtonDataBase = new System.Windows.Forms.Panel();
            this.btnForm1DateBase = new System.Windows.Forms.Button();
            this.btnForm1LogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.pnlForm1CenterDisplay.SuspendLayout();
            this.uperPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide)).BeginInit();
            this.pnlMenuVartical.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlManu.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.pnlConvertionContainer.SuspendLayout();
            this.pnlButtonDataBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(66, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(908, 554);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pnlForm1CenterDisplay);
            this.panel3.Controls.Add(this.uperPanel);
            this.panel3.Controls.Add(this.pnlMenuVartical);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(974, 554);
            this.panel3.TabIndex = 1;
            // 
            // pnlForm1CenterDisplay
            // 
            this.pnlForm1CenterDisplay.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlForm1CenterDisplay.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlForm1CenterDisplay.BackgroundImage")));
            this.pnlForm1CenterDisplay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlForm1CenterDisplay.Controls.Add(this.pnlWelcomePicture);
            this.pnlForm1CenterDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlForm1CenterDisplay.Location = new System.Drawing.Point(200, 50);
            this.pnlForm1CenterDisplay.Name = "pnlForm1CenterDisplay";
            this.pnlForm1CenterDisplay.Size = new System.Drawing.Size(774, 504);
            this.pnlForm1CenterDisplay.TabIndex = 9;
            // 
            // pnlWelcomePicture
            // 
            this.pnlWelcomePicture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlWelcomePicture.BackgroundImage")));
            this.pnlWelcomePicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlWelcomePicture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlWelcomePicture.Location = new System.Drawing.Point(12, 41);
            this.pnlWelcomePicture.Name = "pnlWelcomePicture";
            this.pnlWelcomePicture.Size = new System.Drawing.Size(322, 429);
            this.pnlWelcomePicture.TabIndex = 0;
            // 
            // uperPanel
            // 
            this.uperPanel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.uperPanel.Controls.Add(this.btnSlide);
            this.uperPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.uperPanel.Location = new System.Drawing.Point(200, 0);
            this.uperPanel.Name = "uperPanel";
            this.uperPanel.Size = new System.Drawing.Size(774, 50);
            this.uperPanel.TabIndex = 8;
            // 
            // btnSlide
            // 
            this.btnSlide.Image = ((System.Drawing.Image)(resources.GetObject("btnSlide.Image")));
            this.btnSlide.Location = new System.Drawing.Point(1, 0);
            this.btnSlide.Name = "btnSlide";
            this.btnSlide.Size = new System.Drawing.Size(35, 35);
            this.btnSlide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSlide.TabIndex = 0;
            this.btnSlide.TabStop = false;
            this.btnSlide.Click += new System.EventHandler(this.btnSlide_Click);
            // 
            // pnlMenuVartical
            // 
            this.pnlMenuVartical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlMenuVartical.Controls.Add(this.panel4);
            this.pnlMenuVartical.Controls.Add(this.pnlManu);
            this.pnlMenuVartical.Controls.Add(this.btnSettings);
            this.pnlMenuVartical.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuVartical.Location = new System.Drawing.Point(0, 0);
            this.pnlMenuVartical.MaximumSize = new System.Drawing.Size(200, 554);
            this.pnlMenuVartical.MinimumSize = new System.Drawing.Size(56, 554);
            this.pnlMenuVartical.Name = "pnlMenuVartical";
            this.pnlMenuVartical.Size = new System.Drawing.Size(200, 554);
            this.pnlMenuVartical.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(121)))), ((int)(((byte)(204)))));
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 81);
            this.panel4.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(50, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(124, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(62, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pnlManu
            // 
            this.pnlManu.Controls.Add(this.flowLayoutPanel1);
            this.pnlManu.Location = new System.Drawing.Point(0, 103);
            this.pnlManu.Name = "pnlManu";
            this.pnlManu.Size = new System.Drawing.Size(200, 379);
            this.pnlManu.TabIndex = 8;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.btnForm1Home);
            this.flowLayoutPanel1.Controls.Add(this.btnForm1StandardCalculator);
            this.flowLayoutPanel1.Controls.Add(this.btnScientificCalculator);
            this.flowLayoutPanel1.Controls.Add(this.btnNotepadCalculator);
            this.flowLayoutPanel1.Controls.Add(this.btnConversion);
            this.flowLayoutPanel1.Controls.Add(this.pnlConvertionContainer);
            this.flowLayoutPanel1.Controls.Add(this.pnlButtonDataBase);
            this.flowLayoutPanel1.Controls.Add(this.btnForm1LogOut);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 379);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // btnForm1Home
            // 
            this.btnForm1Home.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnForm1Home.FlatAppearance.BorderSize = 0;
            this.btnForm1Home.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.btnForm1Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1Home.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1Home.ForeColor = System.Drawing.Color.White;
            this.btnForm1Home.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1Home.Image")));
            this.btnForm1Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1Home.Location = new System.Drawing.Point(3, 3);
            this.btnForm1Home.Name = "btnForm1Home";
            this.btnForm1Home.Size = new System.Drawing.Size(172, 50);
            this.btnForm1Home.TabIndex = 12;
            this.btnForm1Home.Text = "          Home";
            this.btnForm1Home.UseVisualStyleBackColor = true;
            this.btnForm1Home.Click += new System.EventHandler(this.btnForm1Home_Click);
            // 
            // btnForm1StandardCalculator
            // 
            this.btnForm1StandardCalculator.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnForm1StandardCalculator.FlatAppearance.BorderSize = 0;
            this.btnForm1StandardCalculator.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.btnForm1StandardCalculator.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1StandardCalculator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1StandardCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1StandardCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1StandardCalculator.ForeColor = System.Drawing.Color.White;
            this.btnForm1StandardCalculator.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1StandardCalculator.Image")));
            this.btnForm1StandardCalculator.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1StandardCalculator.Location = new System.Drawing.Point(3, 59);
            this.btnForm1StandardCalculator.Name = "btnForm1StandardCalculator";
            this.btnForm1StandardCalculator.Size = new System.Drawing.Size(172, 50);
            this.btnForm1StandardCalculator.TabIndex = 16;
            this.btnForm1StandardCalculator.Text = "          Standard";
            this.btnForm1StandardCalculator.UseVisualStyleBackColor = true;
            this.btnForm1StandardCalculator.Click += new System.EventHandler(this.btnForm1StandardCalculator_Click);
            // 
            // btnScientificCalculator
            // 
            this.btnScientificCalculator.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnScientificCalculator.FlatAppearance.BorderSize = 0;
            this.btnScientificCalculator.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.btnScientificCalculator.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnScientificCalculator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnScientificCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScientificCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScientificCalculator.ForeColor = System.Drawing.Color.White;
            this.btnScientificCalculator.Image = ((System.Drawing.Image)(resources.GetObject("btnScientificCalculator.Image")));
            this.btnScientificCalculator.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnScientificCalculator.Location = new System.Drawing.Point(3, 115);
            this.btnScientificCalculator.Name = "btnScientificCalculator";
            this.btnScientificCalculator.Size = new System.Drawing.Size(172, 50);
            this.btnScientificCalculator.TabIndex = 15;
            this.btnScientificCalculator.Text = "          Scientific";
            this.btnScientificCalculator.UseVisualStyleBackColor = true;
            // 
            // btnNotepadCalculator
            // 
            this.btnNotepadCalculator.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
            this.btnNotepadCalculator.FlatAppearance.BorderSize = 0;
            this.btnNotepadCalculator.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnNotepadCalculator.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnNotepadCalculator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnNotepadCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotepadCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNotepadCalculator.ForeColor = System.Drawing.Color.White;
            this.btnNotepadCalculator.Image = ((System.Drawing.Image)(resources.GetObject("btnNotepadCalculator.Image")));
            this.btnNotepadCalculator.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNotepadCalculator.Location = new System.Drawing.Point(3, 171);
            this.btnNotepadCalculator.Name = "btnNotepadCalculator";
            this.btnNotepadCalculator.Size = new System.Drawing.Size(172, 50);
            this.btnNotepadCalculator.TabIndex = 28;
            this.btnNotepadCalculator.Text = "                Notepad                   Calculator";
            this.btnNotepadCalculator.UseVisualStyleBackColor = true;
            // 
            // btnConversion
            // 
            this.btnConversion.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnConversion.FlatAppearance.BorderSize = 0;
            this.btnConversion.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.btnConversion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnConversion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnConversion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConversion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConversion.ForeColor = System.Drawing.Color.White;
            this.btnConversion.Image = ((System.Drawing.Image)(resources.GetObject("btnConversion.Image")));
            this.btnConversion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConversion.Location = new System.Drawing.Point(3, 227);
            this.btnConversion.Name = "btnConversion";
            this.btnConversion.Size = new System.Drawing.Size(172, 50);
            this.btnConversion.TabIndex = 19;
            this.btnConversion.Text = "          Conversion";
            this.btnConversion.UseVisualStyleBackColor = true;
            this.btnConversion.Click += new System.EventHandler(this.btnConversion_Click);
            // 
            // pnlConvertionContainer
            // 
            this.pnlConvertionContainer.Controls.Add(this.btnAngle);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbDiscount);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbSpeed);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbPressure);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbEnergy);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbTemp);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbTime);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbMass);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbVolume);
            this.pnlConvertionContainer.Controls.Add(this.btnForm1SbArea);
            this.pnlConvertionContainer.Controls.Add(this.button7);
            this.pnlConvertionContainer.Location = new System.Drawing.Point(2, 282);
            this.pnlConvertionContainer.Margin = new System.Windows.Forms.Padding(2);
            this.pnlConvertionContainer.MaximumSize = new System.Drawing.Size(177, 504);
            this.pnlConvertionContainer.MinimumSize = new System.Drawing.Size(177, 0);
            this.pnlConvertionContainer.Name = "pnlConvertionContainer";
            this.pnlConvertionContainer.Size = new System.Drawing.Size(177, 0);
            this.pnlConvertionContainer.TabIndex = 22;
            // 
            // btnAngle
            // 
            this.btnAngle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnAngle.FlatAppearance.BorderSize = 0;
            this.btnAngle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnAngle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAngle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAngle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAngle.ForeColor = System.Drawing.Color.White;
            this.btnAngle.Image = ((System.Drawing.Image)(resources.GetObject("btnAngle.Image")));
            this.btnAngle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAngle.Location = new System.Drawing.Point(5, 392);
            this.btnAngle.Margin = new System.Windows.Forms.Padding(2);
            this.btnAngle.Name = "btnAngle";
            this.btnAngle.Size = new System.Drawing.Size(170, 42);
            this.btnAngle.TabIndex = 118;
            this.btnAngle.Text = "        Angle";
            this.btnAngle.UseVisualStyleBackColor = false;
            this.btnAngle.Click += new System.EventHandler(this.btnAngle_Click);
            // 
            // btnForm1SbDiscount
            // 
            this.btnForm1SbDiscount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbDiscount.FlatAppearance.BorderSize = 0;
            this.btnForm1SbDiscount.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbDiscount.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbDiscount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbDiscount.ForeColor = System.Drawing.Color.White;
            this.btnForm1SbDiscount.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbDiscount.Image")));
            this.btnForm1SbDiscount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbDiscount.Location = new System.Drawing.Point(2, 6);
            this.btnForm1SbDiscount.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbDiscount.Name = "btnForm1SbDiscount";
            this.btnForm1SbDiscount.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbDiscount.TabIndex = 113;
            this.btnForm1SbDiscount.Text = "        Power";
            this.btnForm1SbDiscount.UseVisualStyleBackColor = false;
            this.btnForm1SbDiscount.Click += new System.EventHandler(this.btnForm1SbDiscount_Click);
            // 
            // btnForm1SbSpeed
            // 
            this.btnForm1SbSpeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbSpeed.FlatAppearance.BorderSize = 0;
            this.btnForm1SbSpeed.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbSpeed.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbSpeed.ForeColor = System.Drawing.SystemColors.Control;
            this.btnForm1SbSpeed.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbSpeed.Image")));
            this.btnForm1SbSpeed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbSpeed.Location = new System.Drawing.Point(2, 51);
            this.btnForm1SbSpeed.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbSpeed.Name = "btnForm1SbSpeed";
            this.btnForm1SbSpeed.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbSpeed.TabIndex = 109;
            this.btnForm1SbSpeed.Text = "       Speed";
            this.btnForm1SbSpeed.UseVisualStyleBackColor = false;
            this.btnForm1SbSpeed.Click += new System.EventHandler(this.btnForm1SbSpeed_Click);
            // 
            // btnForm1SbPressure
            // 
            this.btnForm1SbPressure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbPressure.FlatAppearance.BorderSize = 0;
            this.btnForm1SbPressure.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbPressure.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbPressure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbPressure.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbPressure.ForeColor = System.Drawing.Color.White;
            this.btnForm1SbPressure.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbPressure.Image")));
            this.btnForm1SbPressure.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbPressure.Location = new System.Drawing.Point(4, 98);
            this.btnForm1SbPressure.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbPressure.Name = "btnForm1SbPressure";
            this.btnForm1SbPressure.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbPressure.TabIndex = 112;
            this.btnForm1SbPressure.Text = "         Pressure";
            this.btnForm1SbPressure.UseVisualStyleBackColor = false;
            this.btnForm1SbPressure.Click += new System.EventHandler(this.btnForm1SbPressure_Click);
            // 
            // btnForm1SbEnergy
            // 
            this.btnForm1SbEnergy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbEnergy.FlatAppearance.BorderSize = 0;
            this.btnForm1SbEnergy.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbEnergy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbEnergy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbEnergy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbEnergy.ForeColor = System.Drawing.SystemColors.Control;
            this.btnForm1SbEnergy.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbEnergy.Image")));
            this.btnForm1SbEnergy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbEnergy.Location = new System.Drawing.Point(4, 143);
            this.btnForm1SbEnergy.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbEnergy.Name = "btnForm1SbEnergy";
            this.btnForm1SbEnergy.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbEnergy.TabIndex = 117;
            this.btnForm1SbEnergy.Text = "       Energy";
            this.btnForm1SbEnergy.UseVisualStyleBackColor = false;
            this.btnForm1SbEnergy.Click += new System.EventHandler(this.btnForm1SbEnergy_Click);
            // 
            // btnForm1SbTemp
            // 
            this.btnForm1SbTemp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbTemp.FlatAppearance.BorderSize = 0;
            this.btnForm1SbTemp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbTemp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbTemp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbTemp.ForeColor = System.Drawing.SystemColors.Control;
            this.btnForm1SbTemp.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbTemp.Image")));
            this.btnForm1SbTemp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbTemp.Location = new System.Drawing.Point(4, 188);
            this.btnForm1SbTemp.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbTemp.Name = "btnForm1SbTemp";
            this.btnForm1SbTemp.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbTemp.TabIndex = 115;
            this.btnForm1SbTemp.Text = "        Temp";
            this.btnForm1SbTemp.UseVisualStyleBackColor = false;
            this.btnForm1SbTemp.Click += new System.EventHandler(this.btnForm1SbTemp_Click);
            // 
            // btnForm1SbTime
            // 
            this.btnForm1SbTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbTime.FlatAppearance.BorderSize = 0;
            this.btnForm1SbTime.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbTime.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbTime.ForeColor = System.Drawing.SystemColors.Control;
            this.btnForm1SbTime.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbTime.Image")));
            this.btnForm1SbTime.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbTime.Location = new System.Drawing.Point(4, 247);
            this.btnForm1SbTime.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbTime.Name = "btnForm1SbTime";
            this.btnForm1SbTime.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbTime.TabIndex = 110;
            this.btnForm1SbTime.Text = "        Time";
            this.btnForm1SbTime.UseVisualStyleBackColor = false;
            this.btnForm1SbTime.Click += new System.EventHandler(this.btnForm1SbTime_Click);
            // 
            // btnForm1SbMass
            // 
            this.btnForm1SbMass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbMass.FlatAppearance.BorderSize = 0;
            this.btnForm1SbMass.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbMass.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbMass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbMass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbMass.ForeColor = System.Drawing.SystemColors.Control;
            this.btnForm1SbMass.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbMass.Image")));
            this.btnForm1SbMass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbMass.Location = new System.Drawing.Point(4, 293);
            this.btnForm1SbMass.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbMass.Name = "btnForm1SbMass";
            this.btnForm1SbMass.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbMass.TabIndex = 114;
            this.btnForm1SbMass.Text = "        Mass";
            this.btnForm1SbMass.UseVisualStyleBackColor = false;
            this.btnForm1SbMass.Click += new System.EventHandler(this.btnForm1SbMass_Click);
            // 
            // btnForm1SbVolume
            // 
            this.btnForm1SbVolume.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbVolume.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnForm1SbVolume.FlatAppearance.BorderSize = 0;
            this.btnForm1SbVolume.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbVolume.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbVolume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbVolume.ForeColor = System.Drawing.Color.White;
            this.btnForm1SbVolume.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbVolume.Image")));
            this.btnForm1SbVolume.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbVolume.Location = new System.Drawing.Point(4, 342);
            this.btnForm1SbVolume.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbVolume.Name = "btnForm1SbVolume";
            this.btnForm1SbVolume.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbVolume.TabIndex = 116;
            this.btnForm1SbVolume.Text = "        Volume";
            this.btnForm1SbVolume.UseVisualStyleBackColor = false;
            this.btnForm1SbVolume.Click += new System.EventHandler(this.btnForm1SbVolume_Click);
            // 
            // btnForm1SbArea
            // 
            this.btnForm1SbArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnForm1SbArea.FlatAppearance.BorderSize = 0;
            this.btnForm1SbArea.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnForm1SbArea.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1SbArea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1SbArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1SbArea.ForeColor = System.Drawing.Color.White;
            this.btnForm1SbArea.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1SbArea.Image")));
            this.btnForm1SbArea.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1SbArea.Location = new System.Drawing.Point(4, 448);
            this.btnForm1SbArea.Margin = new System.Windows.Forms.Padding(2);
            this.btnForm1SbArea.Name = "btnForm1SbArea";
            this.btnForm1SbArea.Size = new System.Drawing.Size(170, 42);
            this.btnForm1SbArea.TabIndex = 106;
            this.btnForm1SbArea.Text = "       Area";
            this.btnForm1SbArea.UseVisualStyleBackColor = false;
            this.btnForm1SbArea.Click += new System.EventHandler(this.btnForm1SbArea_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(2, 557);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(170, 42);
            this.button7.TabIndex = 107;
            this.button7.Text = "        Data";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // pnlButtonDataBase
            // 
            this.pnlButtonDataBase.Controls.Add(this.btnForm1DateBase);
            this.pnlButtonDataBase.Location = new System.Drawing.Point(3, 287);
            this.pnlButtonDataBase.Name = "pnlButtonDataBase";
            this.pnlButtonDataBase.Size = new System.Drawing.Size(172, 50);
            this.pnlButtonDataBase.TabIndex = 0;
            // 
            // btnForm1DateBase
            // 
            this.btnForm1DateBase.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
            this.btnForm1DateBase.FlatAppearance.BorderSize = 0;
            this.btnForm1DateBase.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1DateBase.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnForm1DateBase.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1DateBase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1DateBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1DateBase.ForeColor = System.Drawing.Color.White;
            this.btnForm1DateBase.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1DateBase.Image")));
            this.btnForm1DateBase.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1DateBase.Location = new System.Drawing.Point(1, 0);
            this.btnForm1DateBase.Name = "btnForm1DateBase";
            this.btnForm1DateBase.Size = new System.Drawing.Size(172, 50);
            this.btnForm1DateBase.TabIndex = 23;
            this.btnForm1DateBase.Text = "          Data Base";
            this.btnForm1DateBase.UseVisualStyleBackColor = true;
            this.btnForm1DateBase.Click += new System.EventHandler(this.btnForm1DateBase_Click);
            // 
            // btnForm1LogOut
            // 
            this.btnForm1LogOut.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
            this.btnForm1LogOut.FlatAppearance.BorderSize = 0;
            this.btnForm1LogOut.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnForm1LogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnForm1LogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.btnForm1LogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1LogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1LogOut.ForeColor = System.Drawing.Color.White;
            this.btnForm1LogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnForm1LogOut.Image")));
            this.btnForm1LogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnForm1LogOut.Location = new System.Drawing.Point(3, 343);
            this.btnForm1LogOut.Name = "btnForm1LogOut";
            this.btnForm1LogOut.Size = new System.Drawing.Size(172, 50);
            this.btnForm1LogOut.TabIndex = 28;
            this.btnForm1LogOut.Text = "          Log Out";
            this.btnForm1LogOut.UseVisualStyleBackColor = true;
            this.btnForm1LogOut.Click += new System.EventHandler(this.btnForm1LogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.White;
            this.btnSettings.Image = ((System.Drawing.Image)(resources.GetObject("btnSettings.Image")));
            this.btnSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettings.Location = new System.Drawing.Point(-1, 502);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(203, 50);
            this.btnSettings.TabIndex = 7;
            this.btnSettings.Text = "   Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(972, 553);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Math Expo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel3.ResumeLayout(false);
            this.pnlForm1CenterDisplay.ResumeLayout(false);
            this.uperPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide)).EndInit();
            this.pnlMenuVartical.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlManu.ResumeLayout(false);
            this.pnlManu.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.pnlConvertionContainer.ResumeLayout(false);
            this.pnlButtonDataBase.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnlMenuVartical;
        private System.Windows.Forms.Panel pnlForm1CenterDisplay;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Panel pnlManu;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnForm1StandardCalculator;
        private System.Windows.Forms.Button btnScientificCalculator;
        private System.Windows.Forms.Button btnForm1Home;
        private System.Windows.Forms.Panel pnlWelcomePicture;
        private System.Windows.Forms.Panel pnlConvertionContainer;
        private System.Windows.Forms.Button btnForm1SbDiscount;
        private System.Windows.Forms.Button btnForm1SbSpeed;
        private System.Windows.Forms.Button btnForm1SbPressure;
        private System.Windows.Forms.Button btnForm1SbEnergy;
        private System.Windows.Forms.Button btnForm1SbTemp;
        private System.Windows.Forms.Button btnForm1SbTime;
        private System.Windows.Forms.Button btnForm1SbMass;
        private System.Windows.Forms.Button btnForm1SbVolume;
        private System.Windows.Forms.Button btnForm1SbArea;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnConversion;
        private System.Windows.Forms.Button btnForm1DateBase;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel uperPanel;
        private System.Windows.Forms.PictureBox btnSlide;
        private System.Windows.Forms.Panel pnlButtonDataBase;
        private System.Windows.Forms.Button btnForm1LogOut;
        private System.Windows.Forms.Button btnNotepadCalculator;
        private System.Windows.Forms.Button btnAngle;
    }
}

