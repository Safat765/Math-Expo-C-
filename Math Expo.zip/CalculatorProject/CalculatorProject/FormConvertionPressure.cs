﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionPressure : Form
    {

        double num, num1, num2;
        public FormConvertionPressure()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Atmospheres-----------------
                if (ComboBox1 == "Atmospheres" && ComboBox2 == "Bars")
                {
                    string a = "1.01325";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Atmospheres" && ComboBox2 == "Kilopascals")
                {
                    string a = "101.325";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Atmospheres" && ComboBox2 == "Millimeters of mercury")
                {
                    string a = "760.1275";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Atmospheres" && ComboBox2 == "Pascals")
                {
                    string a = "101325";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Atmospheres" && ComboBox2 == "Pound per square inch")
                {
                    string a = "14.69595";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Bars-----------------
                else if (ComboBox1 == "Bars" && ComboBox2 == "Atmospheres")
                {
                    string a = "0.986923";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Bars" && ComboBox2 == "Kilopascals")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Bars" && ComboBox2 == "Millimeters of mercury")
                {
                    string a = "750.1875";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Bars" && ComboBox2 == "Pascals")
                {
                    string a = "100000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Bars" && ComboBox2 == "Pound per square inch")
                {
                    string a = "14.50377";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Kilopascals-----------------
                else if (ComboBox1 == "Kilopascals" && ComboBox2 == "Atmospheres")
                {
                    string a = "0.009869";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilopascals" && ComboBox2 == "Bars")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilopascals" && ComboBox2 == "Millimeters of mercury")
                {
                    string a = "7.501875";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilopascals" && ComboBox2 == "Pascals")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilopascals" && ComboBox2 == "Pound per square inch")
                {
                    string a = "0.145038";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Millimeters of mercury-----------------
                else if (ComboBox1 == "Millimeters of mercury" && ComboBox2 == "Atmospheres")
                {
                    string a = "0.001316";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millimeters of mercury" && ComboBox2 == "Bars")
                {
                    string a = "0.001333";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millimeters of mercury" && ComboBox2 == "Kilopascals")
                {
                    string a = "0.1333";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millimeters of mercury" && ComboBox2 == "Pascals")
                {
                    string a = "133.3";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millimeters of mercury" && ComboBox2 == "Pound per square inch")
                {
                    string a = "0.019334";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Pascals-----------------
                else if (ComboBox1 == "Pascals" && ComboBox2 == "Atmospheres")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pascals" && ComboBox2 == "Bars")
                {
                    string a = "0.00001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pascals" && ComboBox2 == "Kilopascals")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pascals" && ComboBox2 == "Millimeters of mercury")
                {
                    string a = "0.007502";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pascals" && ComboBox2 == "Pound per square inch")
                {
                    string a = "0.000145";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from -----------------
                else if (ComboBox1 == "Pound per square inch" && ComboBox2 == "Atmospheres")
                {
                    string a = "0.068046";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pound per square inch" && ComboBox2 == "Bars")
                {
                    string a = "0.068948";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pound per square inch" && ComboBox2 == "Kilopascals")
                {
                    string a = "6.894757";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pound per square inch" && ComboBox2 == "Millimeters of mercury")
                {
                    string a = "51.72361";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Pound per square inch" && ComboBox2 == "Pascals")
                {
                    string a = "6894.757";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }
    }
}
