﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionSpeed : Form
    {

        double num, num1, num2;
        public FormConvertionSpeed()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }
        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Centimeters per second-----------------
                if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Meters per second")
                {
                    string a = "0.01";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "0.036";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Feet per second")
                {
                    string a = "0.032808";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Miles per hour")
                {
                    string a = "0.022371";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Knots")
                {
                    string a = "0.01944";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Centimeters per second" && ComboBox2 == "Mach")
                {
                    string a = "0.000029";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Meters per second-----------------
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Centimeters per second")
                {
                    string a = "100";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "3.6";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Feet per second")
                {
                    string a = "3.28084";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Miles per hour")
                {
                    string a = "2.237136";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Knots")
                {
                    string a = "1.944012";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Meters per second" && ComboBox2 == "Mach")
                {
                    string a = "0.002939";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Kilometers per hour-----------------
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Centimeters per second")
                {
                    string a = "27.77778";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Meters per second")
                {
                    string a = "0.277778";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Feet per second")
                {
                    string a = "0.911344";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Miles per hour")
                {
                    string a = "0.621427";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Knots")
                {
                    string a = "0.540003";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Kilometers per hour" && ComboBox2 == "Mach")
                {
                    string a = "0.000816";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Feet per second-----------------
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Centimeters per second")
                {
                    string a = "30.48";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Meters per second")
                {
                    string a = "0.3048";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "1.09728";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Miles per hour")
                {
                    string a = "0.681879";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Knots")
                {
                    string a = "0.592535";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Feet per second" && ComboBox2 == "Mach")
                {
                    string a = "0.000896";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Miles per hour-----------------
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Centimeters per second")
                {
                    string a = "44.7";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Meters per second")
                {
                    string a = "0.447";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "1.6092";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Feet per second")
                {
                    string a = "1.466535";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Knots")
                {
                    string a = "0.868974";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Miles per hour" && ComboBox2 == "Mach")
                {
                    string a = "0.001314";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Knots-----------------
                else if (ComboBox1 == "Knots" && ComboBox2 == "Centimeters per second")
                {
                    string a = "51.44";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Knots" && ComboBox2 == "Meters per second")
                {
                    string a = "0.5144";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Knots" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "1.85184";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Knots" && ComboBox2 == "Feet per second")
                {
                    string a = "1.687664";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Knots" && ComboBox2 == "Miles per hour")
                {
                    string a = "1.150783";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Knots" && ComboBox2 == "Mach")
                {
                    string a = "0.001512";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Mach-----------------
                else if (ComboBox1 == "Mach" && ComboBox2 == "Centimeters per second")
                {
                    string a = "34030";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Mach" && ComboBox2 == "Meters per second")
                {
                    string a = "340.3";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Mach" && ComboBox2 == "Kilometers per hour")
                {
                    string a = "1225.08";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Mach" && ComboBox2 == "Feet per second")
                {
                    string a = "1116.47";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Mach" && ComboBox2 == "Miles per hour")
                {
                    string a = "761.2975";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Mach" && ComboBox2 == "Knots")
                {
                    string a = "661.5474";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }
    }
}
