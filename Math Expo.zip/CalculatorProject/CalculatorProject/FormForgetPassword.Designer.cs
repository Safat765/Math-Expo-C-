﻿namespace CalculatorProject
{
    partial class FormForgetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormForgetPassword));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtFormForgetPasswordUserID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.btnFormForgetPasswordCancel = new System.Windows.Forms.Button();
            this.btnFormForgetPasswordDone = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtFormForgetPasswordConfirmPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtFormForgetPasswordNewPassword = new System.Windows.Forms.TextBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(946, 557);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel13);
            this.panel4.Controls.Add(this.btnFormForgetPasswordCancel);
            this.panel4.Controls.Add(this.btnFormForgetPasswordDone);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(318, 95);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(619, 411);
            this.panel4.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.label2);
            this.panel13.Controls.Add(this.panel16);
            this.panel13.Location = new System.Drawing.Point(13, 15);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(603, 83);
            this.panel13.TabIndex = 10;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.txtFormForgetPasswordUserID);
            this.panel14.Location = new System.Drawing.Point(218, 11);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(375, 55);
            this.panel14.TabIndex = 5;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Location = new System.Drawing.Point(4, 44);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(370, 1);
            this.panel15.TabIndex = 8;
            // 
            // txtFormForgetPasswordUserID
            // 
            this.txtFormForgetPasswordUserID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFormForgetPasswordUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFormForgetPasswordUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormForgetPasswordUserID.ForeColor = System.Drawing.Color.White;
            this.txtFormForgetPasswordUserID.Location = new System.Drawing.Point(4, 15);
            this.txtFormForgetPasswordUserID.Name = "txtFormForgetPasswordUserID";
            this.txtFormForgetPasswordUserID.Size = new System.Drawing.Size(370, 29);
            this.txtFormForgetPasswordUserID.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(76, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "User ID";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel16.Enabled = false;
            this.panel16.Location = new System.Drawing.Point(15, 11);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(53, 55);
            this.panel16.TabIndex = 0;
            // 
            // btnFormForgetPasswordCancel
            // 
            this.btnFormForgetPasswordCancel.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnFormForgetPasswordCancel.FlatAppearance.BorderSize = 2;
            this.btnFormForgetPasswordCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnFormForgetPasswordCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.btnFormForgetPasswordCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFormForgetPasswordCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFormForgetPasswordCancel.ForeColor = System.Drawing.Color.White;
            this.btnFormForgetPasswordCancel.Location = new System.Drawing.Point(343, 342);
            this.btnFormForgetPasswordCancel.Name = "btnFormForgetPasswordCancel";
            this.btnFormForgetPasswordCancel.Size = new System.Drawing.Size(134, 43);
            this.btnFormForgetPasswordCancel.TabIndex = 9;
            this.btnFormForgetPasswordCancel.Text = "Cancel";
            this.btnFormForgetPasswordCancel.UseVisualStyleBackColor = true;
            this.btnFormForgetPasswordCancel.Click += new System.EventHandler(this.btnFormForgetPasswordCancel_Click);
            // 
            // btnFormForgetPasswordDone
            // 
            this.btnFormForgetPasswordDone.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.btnFormForgetPasswordDone.FlatAppearance.BorderSize = 2;
            this.btnFormForgetPasswordDone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnFormForgetPasswordDone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.btnFormForgetPasswordDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFormForgetPasswordDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFormForgetPasswordDone.ForeColor = System.Drawing.Color.White;
            this.btnFormForgetPasswordDone.Location = new System.Drawing.Point(171, 342);
            this.btnFormForgetPasswordDone.Name = "btnFormForgetPasswordDone";
            this.btnFormForgetPasswordDone.Size = new System.Drawing.Size(134, 43);
            this.btnFormForgetPasswordDone.TabIndex = 8;
            this.btnFormForgetPasswordDone.Text = "Done";
            this.btnFormForgetPasswordDone.UseVisualStyleBackColor = true;
            this.btnFormForgetPasswordDone.Click += new System.EventHandler(this.btnFormForgetPasswordDone_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel12);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Location = new System.Drawing.Point(14, 217);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(602, 83);
            this.panel9.TabIndex = 6;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel12.Enabled = false;
            this.panel12.Location = new System.Drawing.Point(15, 11);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(53, 55);
            this.panel12.TabIndex = 10;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.txtFormForgetPasswordConfirmPassword);
            this.panel10.Location = new System.Drawing.Point(217, 11);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(375, 55);
            this.panel10.TabIndex = 5;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Location = new System.Drawing.Point(4, 44);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(370, 1);
            this.panel11.TabIndex = 8;
            // 
            // txtFormForgetPasswordConfirmPassword
            // 
            this.txtFormForgetPasswordConfirmPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFormForgetPasswordConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFormForgetPasswordConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormForgetPasswordConfirmPassword.ForeColor = System.Drawing.Color.White;
            this.txtFormForgetPasswordConfirmPassword.Location = new System.Drawing.Point(4, 15);
            this.txtFormForgetPasswordConfirmPassword.Name = "txtFormForgetPasswordConfirmPassword";
            this.txtFormForgetPasswordConfirmPassword.Size = new System.Drawing.Size(370, 29);
            this.txtFormForgetPasswordConfirmPassword.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(75, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Confirm Password";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.lblUserID);
            this.panel5.Location = new System.Drawing.Point(14, 116);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(602, 83);
            this.panel5.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel7.Enabled = false;
            this.panel7.Location = new System.Drawing.Point(15, 11);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(53, 55);
            this.panel7.TabIndex = 10;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.txtFormForgetPasswordNewPassword);
            this.panel6.Location = new System.Drawing.Point(217, 11);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(375, 55);
            this.panel6.TabIndex = 5;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(4, 44);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(370, 1);
            this.panel8.TabIndex = 8;
            // 
            // txtFormForgetPasswordNewPassword
            // 
            this.txtFormForgetPasswordNewPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFormForgetPasswordNewPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFormForgetPasswordNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFormForgetPasswordNewPassword.ForeColor = System.Drawing.Color.White;
            this.txtFormForgetPasswordNewPassword.Location = new System.Drawing.Point(4, 15);
            this.txtFormForgetPasswordNewPassword.Name = "txtFormForgetPasswordNewPassword";
            this.txtFormForgetPasswordNewPassword.Size = new System.Drawing.Size(370, 29);
            this.txtFormForgetPasswordNewPassword.TabIndex = 7;
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.ForeColor = System.Drawing.SystemColors.Control;
            this.lblUserID.Location = new System.Drawing.Point(75, 26);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(113, 20);
            this.lblUserID.TabIndex = 4;
            this.lblUserID.Text = "New Password";
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.ForeColor = System.Drawing.Color.White;
            this.lblLogin.Location = new System.Drawing.Point(551, 52);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(191, 26);
            this.lblLogin.TabIndex = 5;
            this.lblLogin.Text = "Forget Password";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(53)))), ((int)(((byte)(71)))));
            this.panel3.Location = new System.Drawing.Point(-1, -4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(950, 43);
            this.panel3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(53)))), ((int)(((byte)(71)))));
            this.panel2.Controls.Add(this.panel17);
            this.panel2.Location = new System.Drawing.Point(-1, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 523);
            this.panel2.TabIndex = 3;
            // 
            // panel17
            // 
            this.panel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel17.BackgroundImage")));
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel17.Location = new System.Drawing.Point(40, 131);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(224, 215);
            this.panel17.TabIndex = 1;
            // 
            // FormForgetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(952, 564);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormForgetPassword";
            this.Text = "Math Expo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormForgetPassword_FormClosed);
            this.Load += new System.EventHandler(this.FormForgetPassword_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormForgetPassword_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtFormForgetPasswordNewPassword;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtFormForgetPasswordConfirmPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnFormForgetPasswordCancel;
        private System.Windows.Forms.Button btnFormForgetPasswordDone;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txtFormForgetPasswordUserID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
    }
}