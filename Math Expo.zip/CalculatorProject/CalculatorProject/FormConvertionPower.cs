﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionPower : Form
    {

        double num, num1, num2;
        public FormConvertionPower()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }
        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from watts-----------------
                if (ComboBox1 == "Watts" && ComboBox2 == "Killowatts")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Watts" && ComboBox2 == "Horsepower (US)")
                {
                    string a = "0.001341";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Watts" && ComboBox2 == "Foot-pounds/minute")
                {
                    string a = "44.25373";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Watts" && ComboBox2 == "BTUs/minute")
                {
                    string a = "0.056869";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Killowatts-----------------
                else if (ComboBox1 == "Killowatts" && ComboBox2 == "Watts")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Killowatts" && ComboBox2 == "Horsepower (US)")
                {
                    string a = "1.342022";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Killowatts" && ComboBox2 == "Foot-pounds/minute")
                {
                    string a = "44253.73";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Killowatts" && ComboBox2 == "BTUs/minute")
                {
                    string a = "56.86902";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Horsepower (US)-----------------
                else if (ComboBox1 == "Horsepower (US)" && ComboBox2 == "Watts")
                {
                    string a = "745.6999";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Horsepower (US)" && ComboBox2 == "Killowatts")
                {
                    string a = "0.7457";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Horsepower (US)" && ComboBox2 == "Foot-pounds/minute")
                {
                    string a = "33000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Horsepower (US)" && ComboBox2 == "BTUs/minute")
                {
                    string a = "42.40722";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Foot-pounds/minute-----------------
                else if (ComboBox1 == "Foot-pounds/minute" && ComboBox2 == "Watts")
                {
                    string a = "0.022597";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds/minute" && ComboBox2 == "Killowatts")
                {
                    string a = "0.000023";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds/minute" && ComboBox2 == "Horsepower (US)")
                {
                    string a = "0.00003";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Foot-pounds/minute" && ComboBox2 == "BTUs/minute")
                {
                    string a = "0.001285";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from BTUs/minute-----------------
                else if (ComboBox1 == "BTUs/minute" && ComboBox2 == "Watts")
                {
                    string a = "17.58427";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "BTUs/minute" && ComboBox2 == "Killowatts")
                {
                    string a = "0.017584";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "BTUs/minute" && ComboBox2 == "Horsepower (US)")
                {
                    string a = "0.023581";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "BTUs/minute" && ComboBox2 == "Foot-pounds/minute")
                {
                    string a = "778.1694";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }
    }
}
