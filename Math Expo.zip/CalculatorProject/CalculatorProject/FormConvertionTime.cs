﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionTime : Form
    {

        double num, num1, num2;
        public FormConvertionTime()
        {
            InitializeComponent();
            this.cmbInput.SelectedIndex = 0;
            this.cmbOutput.SelectedIndex = 0;
        }

        private void CallFromInsideAllFunction(string SNum, string labelInput)
        {
            num1 = Convert.ToDouble(labelInput);
            string a = SNum;
            num2 = Convert.ToDouble(a);
            num = num1 * num2;
            lblOutput.Text = num.ToString();
        }
        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Microseconds-----------------
                if (ComboBox1 == "Microseconds" && ComboBox2 == "Millisecounds")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Seconds")
                {
                    string a = "0.000001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Minutes")
                {
                    string a = "0.000000016666667";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Hours")
                {
                    string a = "0.000000000277778";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Days")
                {
                    string a = "0.000000000011574";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Week")
                {
                    string a = "0.000000000001653";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Microseconds" && ComboBox2 == "Years")
                {
                    string a = "0.000000000000032";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Millisecounds-----------------
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Microseconds")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Seconds")
                {
                    string a = "0.001";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Minutes")
                {
                    string a = "0.000017";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Hours")
                {
                    string a = "0.000000277777778";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Days")
                {
                    string a = "0.000000011574074";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Week")
                {
                    string a = "0.000000001653439";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Millisecounds" && ComboBox2 == "Years")
                {
                    string a = "0.000000000031688";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Seconds-----------------
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Microseconds")
                {
                    string a = "1000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Millisecounds")
                {
                    string a = "1000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Minutes")
                {
                    string a = "0.016667";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Hours")
                {
                    string a = "0.000278";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Days")
                {
                    string a = "0.000012";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Week")
                {
                    string a = "0.000002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Seconds" && ComboBox2 == "Years")
                {
                    string a = "0.000000031688088";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Minutes-----------------
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Microseconds")
                {
                    string a = "60000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Millisecounds")
                {
                    string a = "60000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Seconds")
                {
                    string a = "60";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Hours")
                {
                    string a = "0.016667";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Days")
                {
                    string a = "0.000694";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Week")
                {
                    string a = "0.000099";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Minutes" && ComboBox2 == "Years")
                {
                    string a = "0.000002";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Hours-----------------
                else if (ComboBox1 == "Hours" && ComboBox2 == "Microseconds")
                {
                    string a = "3600000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Millisecounds")
                {
                    string a = "3600000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Seconds")
                {
                    string a = "3600";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Minutes")
                {
                    string a = "60";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Days")
                {
                    string a = "0.041667";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Week")
                {
                    string a = "0.005952";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Hours" && ComboBox2 == "Years")
                {
                    string a = "0.000114";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Days-----------------
                else if (ComboBox1 == "Days" && ComboBox2 == "Microseconds")
                {
                    string a = "86400000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Millisecounds")
                {
                    string a = "86400000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Seconds")
                {
                    string a = "86400";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Minutes")
                {
                    string a = "1440";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Hours")
                {
                    string a = "24";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Week")
                {
                    string a = "0.142857";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Days" && ComboBox2 == "Years")
                {
                    string a = "0.002738";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Week-----------------
                else if (ComboBox1 == "Week" && ComboBox2 == "Microseconds")
                {
                    string a = "604800000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Millisecounds")
                {
                    string a = "604800000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Seconds")
                {
                    string a = "604800";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Minutes")
                {
                    string a = "10080";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Hours")
                {
                    string a = "168";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Days")
                {
                    string a = "7";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Week" && ComboBox2 == "Years")
                {
                    string a = "0.019165";
                    CallFromInsideAllFunction(a, labelInput);
                }
                // -----------------all convertion from Years-----------------
                else if (ComboBox1 == "Years" && ComboBox2 == "Microseconds")
                {
                    string a = "31557600000000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Millisecounds")
                {
                    string a = "31557600000";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Seconds")
                {
                    string a = "31557600";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Minutes")
                {
                    string a = "525960";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Hours")
                {
                    string a = "8766";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Days")
                {
                    string a = "365.25";
                    CallFromInsideAllFunction(a, labelInput);
                }
                else if (ComboBox1 == "Years" && ComboBox2 == "Week")
                {
                    string a = "52.17857";
                    CallFromInsideAllFunction(a, labelInput);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput.Text == cmbOutput.Text)
                {
                    lblOutput.Text = lblInput.Text;
                }
                else if (cmbInput.Text != cmbOutput.Text)
                {
                    this.AllFunction(cmbInput.Text, cmbOutput.Text, lblInput.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput.Text == "0")
                lblInput.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput.Text.Contains("."))
                    {
                        lblInput.Text = lblInput.Text + num.Text;
                    }
                }
                else
                {
                    lblInput.Text = lblInput.Text + num.Text;
                    lblInput.Text = lblInput.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            this.lblInput.Text = "0";
            this.lblOutput.Text = "0";
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput.Text.Length > 0)
            {
                lblInput.Text = lblInput.Text.Remove(lblInput.Text.Length - 1, 1);
            }
            if (lblInput.Text == "")
            {
                lblInput.Text = "0";
            }
        }
    }
}
