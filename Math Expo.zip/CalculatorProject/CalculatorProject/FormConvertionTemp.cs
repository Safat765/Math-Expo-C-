﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorProject
{
    public partial class FormConvertionTemp : Form
    {
        public FormConvertionTemp()
        {
            InitializeComponent();
            this.cmbInput1.SelectedIndex = 0;
            this.cmbOutput1.SelectedIndex = 0;
        }

        private void AllFunction(string ComboBox1, string ComboBox2, string labelInput)
        {
            try
            {
                // -----------------all convertion from Celsius-----------------
                if (ComboBox1 == "Celsius" && ComboBox2 == "Fahrenheit")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = ((Cnum1 * 9) / 5 + 32);
                    lblOutput1.Text = temp1.ToString();
                }
                else if (ComboBox1 == "Celsius" && ComboBox2 == "kelvin")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = (Cnum1 + 273.15);
                    lblOutput1.Text = temp1.ToString();
                }
                // -----------------all convertion from Fahrenheit-----------------

                else if (ComboBox1 == "Fahrenheit" && ComboBox2 == "Celsius")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = (((Cnum1 - 32) * 5) / 9);
                    lblOutput1.Text = temp1.ToString();
                }
                else if (ComboBox1 == "Fahrenheit" && ComboBox2 == "kelvin")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = ((Cnum1 - 32) * (5/9) + 273.15);
                    lblOutput1.Text = temp1.ToString();
                }
                // -----------------all convertion from kelvin-----------------

                else if (ComboBox1 == "kelvin" && ComboBox2 == "Celsius")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = (Cnum1 - 273.15);
                    lblOutput1.Text = temp1.ToString();
                }
                else if (ComboBox1 == "kelvin" && ComboBox2 == "Fahrenheit")
                {
                    double Cnum1 = Convert.ToDouble(labelInput);
                    double temp1 = ((Cnum1 - 273.15) * 1.8 + 32);
                    lblOutput1.Text = temp1.ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Comparecmb()
        {
            try
            {
                if (cmbInput1.Text == cmbOutput1.Text)
                {
                    lblOutput1.Text = lblInput1.Text;
                }
                else if (cmbInput1.Text != cmbOutput1.Text)
                {
                    this.AllFunction(cmbInput1.Text, cmbOutput1.Text, lblInput1.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void AllNumberAndDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (this.lblInput1.Text == "0")
                lblInput1.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!lblInput1.Text.Contains("."))
                    {
                        lblInput1.Text += num.Text;
                    }
                }
                else
                {
                    lblInput1.Text += num.Text;
                    lblInput1.Text = lblInput1.Text;
                }
            }
            this.Comparecmb();
        }

        private void btnVolumeBackSpace_Click(object sender, EventArgs e)
        {
            if (lblInput1.Text.Length > 0)
            {
                lblInput1.Text = lblInput1.Text.Remove(lblInput1.Text.Length - 1, 1);

                this.Comparecmb();

                if (lblOutput1.Text.Length < 1)
                {
                    lblOutput1.Text = "0";
                }
            }
            if (lblInput1.Text == "")
            {
                lblInput1.Text = "0";
            }
        }

        private void btnVolumeClear_Click(object sender, EventArgs e)
        {
            if (cmbInput1.Text == "Celsius" && cmbOutput1.Text == "Fahrenheit")
            {
                this.lblInput1.Text = "0";
                this.lblOutput1.Text = "32";
            }
            else if (cmbInput1.Text == "Celsius" && cmbOutput1.Text == "kelvin")
            {
                this.lblInput1.Text = "0";
                this.lblOutput1.Text = "273.15";
            }
            else if (cmbInput1.Text == "Celsius" && cmbOutput1.Text == "Celsius")
            {
                this.lblInput1.Text = "0";
                this.lblOutput1.Text = "0";
            }
        }
    }
}
